////S.3 sorusunun �ozum kodu
#include <stdio.h>
#include <math.h>
double function_1(double x){
  double y = pow(x,2) - exp(-x) - 3;
   return y;
}
double function_2(double x){
	double y = sqrt(4*exp(-x)+3);
	return y;
}
int main ()
	{
	int n=0;
	double a=1.0,b=2.0,x=1.0,hold;
	double f1= function_1(1),f2= function_1(2),f;
	if(f1*f2<0)
		{
		do
			{
		hold=x;			
		x=function_2(hold);
		f=function_1(x);
		printf("x_%d=%f\tx_%d = %f\tf(%f) = %f\tg(%f)=%f\tError = %f\n",n,hold,n+1,x,x,f,hold,x,fabs(hold-x));
		n++;
		}while(fabs(hold-x)>pow(10,-5));
	}
	printf("xRoot = %f\n",x);
	return 0;
}

