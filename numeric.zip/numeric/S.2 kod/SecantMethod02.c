//a code to find the root of the function function02 by the Secant Method
//function01(x)=pow(x,3)-x-1 , function02(x)=pow(x,3)-pow(x,2)+2*x-4 , function03(x)=pow(x,2)-20;

#include <stdio.h>
#include <math.h>
double fFunction(double x);

int main ()
{ 	double x,f_n,f_nMinusOne,x0,x1,p;
	x0=1.0,x1=2.0;
	int i;
	printf("Finding root of the function with the Secant Method\n");
	do
	{	printf("Iteration %d\n",i);
		f_n=fFunction(x1);
		f_nMinusOne=fFunction(x0);
		printf("f(%f)=%f\tf(%f)=%f\t",x0,f_nMinusOne,x1,f_n);
		x=x1-f_n/((f_n-f_nMinusOne)/(x1-x0));
		x0=x1;
		x1=x;
		printf("\n");
		i++;
	}while (fabs(f_n)>pow(10,-5));
	printf("xRoot = %f\n",x);
	//p=log(fabs(1.477872-1.477967)/fabs(1.481778-1.477967))/log(fabs(1.481778-1.477967)/fabs(1.437500-1.477967));
	//printf("rate of convergence = %f\n",p);
	return 0;
}
double fFunction(double x)
{
	return pow(x,3)-pow(x,2)+2*x-4;
}
