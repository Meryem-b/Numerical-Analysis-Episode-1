//a code to find the root of the function function01 by the Muller Method
//function01(x)=pow(x,3)-x-1 , function02(x)=pow(x,3)-pow(x,2)+2*x-4 , function03(x)=pow(x,2)-20;

#include <stdio.h>
#include <math.h>
double fFunction(double x){
	return pow(x,3)-x-1;
}

int main (){
	int i=1;
	double x,x0,x1,x2,f0,f1,f2,sigm1,sigm2,h1,h2,a,b,c,relativePercentError;
	x0=1.0;
	x1=2.0;
	x2=1.5;
	x=x0;
	do
	{	f0=fFunction(x0);
		f1=fFunction(x1);
		f2=fFunction(x2);
		h1=x1-x0;
		h2=x2-x1;
		sigm1=(f1-f0)/h1;
		sigm2=(f2-f1)/h2;
		a=(sigm2-sigm1)/(h1+h2);
		b=a*h2+sigm2;
		c=f2;
		x=x2+((-2)*c/(b+sqrt(pow(b,2)-4*a*c)));
		relativePercentError=fabs((x-x2)/x)*100;
		printf("iteration = %d x0=%f x1=%f x2=%f f0=%f f1=%f f2=%f a=%f b=%f c=%f x=%f Error=%f\n",i,x0,x1,x2,f0,f1,f2,a,b,c,x,relativePercentError);
		x0=x1;
		x1=x2;
		x2=x;
		i++;		
	}while(relativePercentError>0.001);
	printf("\nxRoot = %f\nf(%f)=%f\n",x,x2,f2);
	return 0;
}
