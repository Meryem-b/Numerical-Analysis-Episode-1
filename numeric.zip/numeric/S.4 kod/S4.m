clear all;
clc;
x=[-1;0];
f1=3*realpow(x(1,1),2)+2*realpow(x(2,1),2)-14;
f2=4*x(1,1)*x(2,1)-x(2,1)+9;
F=[f1;f2];
J=[6*x(1,1),4*x(2,1);4*x(2,1),4*x(1,1)-1];
x
F
J
inv(J)
while(abs(F)>realpow(10,-2))
    x=x-inv(J)*F;
    f1=3*realpow(x(1,1),2)+2*realpow(x(2,1),2)-14;
    f2=4*x(1,1)*x(2,1)-x(2,1)+9;
    F=[f1;f2];
    x
    F
    J=[6*x(1,1),4*x(2,1);4*x(2,1),4*x(1,1)-1];
    J
    inv(J)
end
fprintf('Result\n');
fprintf('x =%.f\n',x);
fprintf('F = %.f\n',F);