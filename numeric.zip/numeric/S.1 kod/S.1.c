//ODEV1 SORU1 COZUMU ICIN C PROGRAMI
#include <stdio.h>
#include <math.h>

	void main()
	{int i=1;
	float  hold;
	char choose;
	double x,hold1=1,hold2=2,y,y1,y2,yLine,yDerivative;
	y1 = 1*exp((-2)*1) + 1*cos(1)-4*sin(2*1);
	y2 = 2*exp((-2)*2) + 2*cos(2)-4*sin(2*2);
	y = x*exp((-2)*x) + x*cos(x)-4*sin(2*x);
	x=1+((2-1)/2);
		if((y1<0&&y2>0)||(y1>0&&y2<0)){
			printf("Press 'a' for Bisection Method, press 'b' for Newton-Raphson Method: ");
			choose=getchar();
			if(choose=='b'){
				x=1.0;
				y = x*exp((-2)*x) + x*cos(x)-4*sin(2*x);
	        	yDerivative=exp((-2)*x)-2*x*exp((-2)*x)+cos(x)-x*sin(x)-8*cos(2*x);
	        	//printf("test value = %f   %f",y,yDerivative);
	        	do
				{
				hold=x;
				x=x-(y/yDerivative);
				y = x*exp((-2)*x) + x*cos(x) - 4*sin(2*x);
	       		yDerivative=exp((-2)*x)-2*x*exp((-2)*x)+cos(x)-x*sin(x)-8*cos(2*x);
				printf("x = %lf y = %lf dy/dx = %lf\n",x,y,yDerivative);
				}while(fabs(hold-x)>pow(10,-5));
	
			}
			x=1+((2-1)/2);
			y = x*exp((-2)*x) + x*cos(x)-4*sin(2*x);
	        if(choose=='a')
				{				
					do
					{
						y = x*exp((-2)*x) + x*cos(x)-4*sin(2*x);
						printf("x = %f\ty = %f\n",x,y);

						if(y<0){
							hold1=x;
							x=x+(hold2-x)/2;

						}
						if(y>0){
							hold2=x;	
							x=hold1+(x-hold1)/2;
						}	
						i++;
					}while(fabs(y)>pow(10,-5));
				}
			}
			else if (choose!='a'&&choose!='b')
				printf("There is no root for the [1,2] interval.\n");

			  
	return;
	}			
